<div id="dcaixa" style="display:block">
Caixa:<br>
<br>
Movimento De: <input type="text" name="data1"> At� <input type="text" name="data2">
</div>