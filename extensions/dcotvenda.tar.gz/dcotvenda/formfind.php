<div id="dcotvenda" style="display:block">
Cota��o de Venda:<br>
<br>
</div>
