<?php
$helperFormEdit = knl_view_hlp_FormEdit::getInstance();
$dsolcompra = $knl_helper->getVar('cabecalho');
/*
//EXEMPLOS:
($dsolcompra['d_sol_compra']->get_data_ini(),"data_ini");
($dsolcompra['d_sol_compra']->get_data_fim(),"data_fim");
?>
<td>Data Inicial: </td><td><?php echo $helperFormEdit->html_CampoData('data_ini'); ?></td>
<td>Data Final: </td><td><?php echo $helperFormEdit->html_CampoData('data_fim'); ?></td>
//FIM EXEMPLOS
*/
?>
