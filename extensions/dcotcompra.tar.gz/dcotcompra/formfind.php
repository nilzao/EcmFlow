<div id="dcotcompra" style="display:block">
Cota��o de Compra:<br>
<br>
</div>
