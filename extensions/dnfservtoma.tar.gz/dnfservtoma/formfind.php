<div id="dnfservtoma" style="display:block">
Nota fiscal de servi�o tomado:<br>
<?php
$knl_helper->setVar("head",'<script type="text/javascript" src="./extensions/cadastronf/cadastronf.js"></script>');
?>
Cnpj/Cpf: <input type="text" name="cnpj" id="cnpj"><a href="#" onclick="popAchaForn();">Achar CNPJ por Raz�o</a><br>
<br>
Data de entrada De: <input type="text" name="data1"> At� <input type="text" name="data2">
</div>
