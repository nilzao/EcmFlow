function popAchaForn() {
    W = 400;
	H = 400;
	url= 'index.php?extdm=cadastronf&action=FornList';
    window.open(url,'',"toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=1,resizable=1,copyhistory=0,width="+W+",height="+H+",top=0,left=0");
}