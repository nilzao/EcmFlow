<div id="dcaixa" style="display:block">
Caixa:<br>
<br>
Movimento De: <input type="text" name="data1"> Até <input type="text" name="data2">
</div>