<div id="dcotvenda" style="display:block">
Cotação de Venda:<br>
<br>
</div>
